<p align='center'>
  <b>🎨 Me siga aqui  🎨</b><br>  
  <a href="https://discord.gg/xYB4knEbtw">Discord</a> |
  <a href="https://www.youtube.com/watch?v=KZi9nwYR6hY&feature=youtu.be">YouTube</a> |
  <a href="https://github.com/SmashKrlh/">Github</a><br><br>
  <img src="https://media.discordapp.net/attachments/1069136524077183027/1155553506149802004/Captura_de_tela_2023-09-24_141550.png?width=892&height=429" style="width: 80%">
</p>

### 🧰 Suporte
- Discord: https://discord.gg/xYB4knEbtw

##  

### 📜 Projeto
Projeto liberado por [Smashzada](https://smashzada7.shop/).

<p align="center">
  <img src="https://img.shields.io/badge/contributions-welcome-brightgreen.svg?style=flat" alt="Contribution Welcome">
  <img src="https://img.shields.io/badge/License-GPLv3-blue.svg" alt="License Badge">
  <img src="https://badges.frapsoft.com/os/v3/open-source.svg?v=103" alt="Open Source">
  <img src="https://visitor-badge.laobi.icu/badge?page_id=Plasmonix" alt="Visitor Count">
</p>